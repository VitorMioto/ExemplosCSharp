﻿using System;

namespace EstudoClasses
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
